package Proyecto;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;

public class Calculadora {
	
	//Creamos Variables para los Numeros y la Operaci�n que quermos Realizar
	String numero1;
	String numero2;
	String signo;
	
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculadora window = new Calculadora();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculadora() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	//Creamos un M�todo para el Punto, y pasamos un par�metro que es el texto que hay en el Panel
	public boolean comprobarPunto(String texto) {
		boolean validar = false;
		//Recorremos el Texto que le pasamos
		for(int i=0; i<texto.length(); i++) {
			//Si uno de los Caracteres es el punto, salimos del bucle y validar ser�a True
			if(texto.substring(i, i+1).equals(".")) {
				validar = true;
				break;
			}
		}
		return validar;
	}
	
	//Creamos un M�todo para Mostrar el Resultado
	private static String Resultado(String numero1, String numero2, String signo) {
		//Pasamos los Valores a Double
		double numero1Final = Double.parseDouble(numero1);
		double numero2Final = Double.parseDouble(numero2);
		
		//Creamos las Variables para el Resultado
		double resultadoOperacion = 0;
		String resultadoFinal;
		
		//Dependiendo de la Operaci�n, el Resultado es Distinto
		if(signo.equals("+")) {
			resultadoOperacion = numero1Final + numero2Final;
		}else if(signo.equals("-")) {
			resultadoOperacion = numero1Final - numero2Final;
		}else if(signo.equals("/")) {
			resultadoOperacion = numero1Final / numero2Final;
		}else if(signo.equals("X")) {
			resultadoOperacion = numero1Final * numero2Final;
		}
		resultadoFinal = String.valueOf(resultadoOperacion);
		//Retornamos Resultado Final
		return resultadoFinal;
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 500, 443);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Activar Modo Oscuro");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setBackground(Color.BLACK);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(10, 375, 155, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Resetear Aspecto");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.getContentPane().setBackground(Color.CYAN);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setBounds(335, 374, 141, 22);
		frame.getContentPane().add(btnNewButton_1);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Tahoma", Font.PLAIN, 25));
		textPane.setBounds(99, 19, 377, 50);
		frame.getContentPane().add(textPane);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero9 = "9";
				textPane.setText(textPane.getText()+numero9);
			}
		});
		btn9.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn9.setBounds(270, 79, 78, 50);
		frame.getContentPane().add(btn9);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero8 = "8";
				textPane.setText(textPane.getText()+numero8);
			}
		});
		btn8.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn8.setBounds(139, 79, 78, 50);
		frame.getContentPane().add(btn8);
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero7 = "7";
				textPane.setText(textPane.getText()+numero7);
			}
		});
		btn7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn7.setBounds(11, 79, 78, 50);
		frame.getContentPane().add(btn7);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero6 = "6";
				textPane.setText(textPane.getText()+numero6);
			}
		});
		btn6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn6.setBounds(270, 162, 78, 50);
		frame.getContentPane().add(btn6);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero5 = "5";
				textPane.setText(textPane.getText()+numero5);
			}
		});
		btn5.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn5.setBounds(139, 162, 78, 50);
		frame.getContentPane().add(btn5);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero4 = "4";
				textPane.setText(textPane.getText()+numero4);
			}
		});
		btn4.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn4.setBounds(11, 162, 78, 50);
		frame.getContentPane().add(btn4);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero3= "3";
				textPane.setText(textPane.getText()+numero3);
			}
		});
		btn3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn3.setBounds(270, 244, 78, 50);
		frame.getContentPane().add(btn3);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero2 = "2";
				textPane.setText(textPane.getText()+numero2);
			}
		});
		btn2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn2.setBounds(139, 244, 78, 50);
		frame.getContentPane().add(btn2);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero1 = "1";
				textPane.setText(textPane.getText()+numero1);
			}
		});
		btn1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn1.setBounds(10, 244, 78, 50);
		frame.getContentPane().add(btn1);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numero0 = "0";
				textPane.setText(textPane.getText()+numero0);
			}
		});
		btn0.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btn0.setBounds(10, 315, 78, 50);
		frame.getContentPane().add(btn0);
		
		JButton btnComa = new JButton(".");
		btnComa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Recogemos el Texto que hay en el Panel
				String texto = textPane.getText();
				
				//Si pulsamos en el Bot�n del Punto, a�adimos 0.
				if(texto.length()<=0) {
					textPane.setText("0.");
				}else {
					//Si no, se a�ade el punto despues del Texto del Panel
					if(!comprobarPunto(textPane.getText())){
						textPane.setText(textPane.getText()+".");
					}
				}
				
				
			}
		});
		btnComa.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnComa.setBounds(139, 315, 78, 50);
		frame.getContentPane().add(btnComa);
		
		JButton btnSuma = new JButton("+");
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Comprobamos si la Cadena de Caracteres no esta vacia
				if(!textPane.getText().equals("")){
					//Asignamos valor al Primer N�mero
					numero1 = textPane.getText();
					//Asignamos el Signo en este caso
					signo = "+";
					//Ponermos el Panel Vacio
					textPane.setText("");
				}
				//Asignamos valor al Segundo N�mero
				numero2 = textPane.getText();
				//Este Proceso se repetir� en cada Bot�n de Operaciones
			}
		});
		btnSuma.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnSuma.setBackground(Color.ORANGE);
		btnSuma.setBounds(398, 79, 78, 50);
		frame.getContentPane().add(btnSuma);
		
		JButton btnResta = new JButton("-");
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textPane.getText().equals("")){
					numero1 = textPane.getText();
					signo = "-";
					textPane.setText("");
				}
				numero2 = textPane.getText();
			}
		});
		btnResta.setBackground(Color.ORANGE);
		btnResta.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnResta.setBounds(398, 162, 78, 50);
		frame.getContentPane().add(btnResta);
		
		JButton btnDivision = new JButton("\u00F7");
		btnDivision.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textPane.getText().equals("")){
					numero1 = textPane.getText();
					signo = "/";
					textPane.setText("");
				}
				numero2 = textPane.getText();
				
			}
		});
		btnDivision.setBackground(Color.ORANGE);
		btnDivision.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnDivision.setBounds(398, 244, 78, 50);
		frame.getContentPane().add(btnDivision);
		
		JButton btnMultiplicar = new JButton("X");
		btnMultiplicar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!textPane.getText().equals("")){
					numero1 = textPane.getText();
					signo = "X";
					textPane.setText("");
				}
				numero2 = textPane.getText();
			}
		});
		btnMultiplicar.setBackground(Color.ORANGE);
		btnMultiplicar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnMultiplicar.setBounds(398, 314, 78, 50);
		frame.getContentPane().add(btnMultiplicar);
		
		JButton btnResultado = new JButton("=");
		btnResultado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String resultado;
				
				numero2 = textPane.getText();
				
				if(!numero2.equals("")) {
					resultado = Resultado(numero1, numero2, signo);
					textPane.setText(resultado);
				}
			}
		});
		btnResultado.setBackground(Color.YELLOW);
		btnResultado.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnResultado.setBounds(270, 314, 78, 50);
		frame.getContentPane().add(btnResultado);
		
		JButton btnBorrar = new JButton("C");
		btnBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textPane.setText("");
			}
		});
		btnBorrar.setBackground(Color.RED);
		btnBorrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnBorrar.setBounds(11, 19, 78, 50);
		frame.getContentPane().add(btnBorrar);
	}
}
